import os
from typing import Callable, List, Optional

from qgis.core import QgsCoordinateReferenceSystem
from qgis.gui import QgsProjectionSelectionWidget
from qgis.PyQt import uic
from qgis.PyQt.QtWidgets import (
    QCheckBox,
    QDialog,
    QFileDialog,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QRadioButton,
    QWidget,
)

from qkan import QKan, enums                                                # QKan: Zugriff auf config, enums: allgemeine QKan-Keys
from qkan.database.dbfunc import DBConnection                               # f�r alle SQL-Operationen in der QKan-DB
from qkan.tools.qkan_utils import list_selected_items                       # hier finden sich viele QKan-Funktionen

from qkan.utils import get_logger, QkanError, QkanDbError, QkanAbortError   # Fehlermeldungen, QKan-Fehlerklassen

logger = get_logger("QKan.template.application_dialog")                     # Anmeldung des Loggers f�r dieses Modul


class _Dialog(QDialog):
    def __init__(
        self,
        default_dir: str,
        tr: Callable,
        parent: Optional[QWidget] = None,
    ):
        # noinspection PyArgumentList
        super().__init__(parent)
        self.setupUi(self)
        self.default_dir = default_dir
        self.tr = tr


IMPORT_CLASS, _ = uic.loadUiType(
    os.path.join(os.path.dirname(__file__), "res", "template_dialog_base.ui")
)


class TemplateDialog(_Dialog, IMPORT_CLASS):  # type: ignore
    tf_database: QLineEdit
    tf_import: QLineEdit
    tf_project: QLineEdit

    pb_database: QPushButton
    pb_import: QPushButton
    pb_project: QPushButton

    pw_epsg: QgsProjectionSelectionWidget

    cb_haltungen: QCheckBox
    cb_schaechte: QCheckBox

    def __init__(
        self,
        default_dir: str,
        tr: Callable,
        parent: Optional[QWidget] = None,
    ):
        # noinspection PyCallByClass,PyArgumentList
        super().__init__(default_dir, tr, parent)

        # Attach events
        self.pb_import.clicked.connect(self.select_import)
        self.pb_project.clicked.connect(self.select_project)
        self.pb_database.clicked.connect(self.select_database)
        # self.button_box.helpRequested.connect(self.click_help)

        # Init fields
        self.tf_database.setText(QKan.config.database.qkan)
        self.tf_import.setText(QKan.config.strakat.import_file)
        # noinspection PyCallByClass,PyArgumentList
        self.pw_epsg.setCrs(QgsCoordinateReferenceSystem.fromEpsgId(QKan.config.epsg))
        self.tf_project.setText(QKan.config.project.file)

        self.cb_schaechte.setChecked(QKan.config.check_import.schaechte)
        self.cb_haltungen.setChecked(QKan.config.check_import.haltungen)

        self.button_box.helpRequested.connect(self.click_help)

    def select_import(self) -> None:
        # noinspection PyArgumentList,PyCallByClass
        filename, _ = QFileDialog.getOpenFileName(
            self,
            self.tr("Zu importierende strakat-Datei"),
            self.default_dir,
            "*.idbm",
        )
        if filename:
            self.tf_import.setText(filename)
            self.default_dir = os.path.dirname(filename)

    def select_project(self) -> None:
        # noinspection PyArgumentList,PyCallByClass
        filename, _ = QFileDialog.getSaveFileName(
            self,
            self.tr("Zu erstellende Projektdatei"),
            self.default_dir,
            "*.qgs",
        )
        if filename:
            self.tf_project.setText(filename)
            self.default_dir = os.path.dirname(filename)

    def select_database(self) -> None:
        # noinspection PyArgumentList,PyCallByClass
        filename, _ = QFileDialog.getSaveFileName(
            self,
            self.tr("Zu erstellende SQLite-Datei"),
            self.default_dir,
            "*.sqlite",
        )
        if filename:
            self.tf_database.setText(filename)
            self.default_dir = os.path.dirname(filename)

    def click_help(self) -> None:
        """Reaktion auf Klick auf Help-Schaltfl�che"""

        help_file = "https://qkan.eu/QKan_Hystem_Extran.html#import-aus-hystem-extran"
        os.startfile(help_file)

    def _load_template_config(self):
        # Read fields from Config

        self.tf_database.setText(QKan.config.database.qkan)
        # Vorgabe Projektname aktivieren, wenn kein Projekt geladen
        self.gb_projectfile.setEnabled(QgsProject.instance().fileName() == '')

    def _save_template_config(self):
        # Read from form and save to config
        QKan.config.database.qkan = self.tf_database.text()
        QKan.config.project.file = self.tf_project.text()
        QKan.config.template.import_dir = self.tf_import.text()

        QKan.config.check_import.haltungen = self.cb_haltungen.isChecked()
        QKan.config.check_import.schaechte = self.cb_schaechte.isChecked()

        QKan.config.save()
