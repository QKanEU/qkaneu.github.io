from qgis.core import Qgis, QgsCoordinateReferenceSystem, QgsProject
from qgis.gui import QgisInterface
from qgis.utils import pluginDirectory

from qkan import QKan, get_default_dir
from qkan.plugin import QKanPlugin

from ._template import TemplateTask
from .application_dialog import TemplateDialog

# noinspection PyUnresolvedReferences
from . import resources


class Template(QKanPlugin):
    def __init__(self, iface: QgisInterface):
        super().__init__(iface)

        default_dir = get_default_dir()                                     # dient dazu, dass bei der Dateiauswahl die Suche
                                                                            # im selben Verzeichnis zu starten
        self.template_dlg = TemplateDialog(default_dir, tr=self.tr)         # Formularinstanz

    # noinspection PyPep8Naming
    def initGui(self) -> None:
        icon_template = ":/plugins/qkan/template/res/icon_template.png"
        QKan.instance.add_action(
            icon_template,
            text=self.tr("Template Plugin"),
            callback=self.openform_templage,
            parent=self.iface.mainWindow(),
        )

    def unload(self) -> None:
        self.template_dlg.close()

    def openform_templage(self) -> None:
        """Anzeigen des Formulars und anschließender Aufruf von _runtemplate"""

        self.template_dlg._load_compare_config()

        self.template_dlg.show()

        # wenn mit der QKan-Datenbank gearbeitet werden soll, muss sichergestellt sein,
        # dass kein Layer bearbeitetbar ist
        if len(layers := get_editable_layers()) > 0:
            _ = ', '.join(layers)
            logger.warning("Anwenderfehler: Es dürfen keine Layer bearbeitbar sein\n"
                              # f"Betroffene Layer: {_}")

        if self.template_dlg.exec_():
            self.template_dlg._save_template_config()

            # wenn mit der QKan-Datenbank gearbeitet werden soll, muss sichergestellt sein,
            # dass kein Layer bearbeitetbar ist
            if len(layers := get_editable_layers()) > 0:
                _ = ', '.join(layers)
                logger.warning("Anwenderfehler: Es dürfen keine Layer bearbeitbar sein\n"
            
            self._runtemplate()

    def _runtemplate(self) -> bool:
        """Start des Moduls

        Einspringpunkt für Test
        """

        self.log.debug("Template gestartet")

        task = TemplateTask()
        task.run()
        del task

        self.log.debug("Template ist fertig!")

        return True

