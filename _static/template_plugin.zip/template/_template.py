from typing import Optional
from qgis.core import Qgis
from qgis.PyQt.QtWidgets import QProgressBar

from qkan import QKan
from qkan.database.dbfunc import DBConnection

from qkan.utils import get_logger

logger = get_logger("QKan.template._template")

progress_bar: Optional[QProgressBar] = None


class TemplateTask:
    def __init__(
        self,
    ):

    def run(self) -> bool:

        iface = QKan.instance.iface                         # iface maskiert, um im Debug-Modus ohne QGIS lauffähig zu sein

        # Create progress bar
        self.progress_bar = QProgressBar(iface.messageBar())
        self.progress_bar.setRange(0, 100)

        status_message = iface.messageBar().createMessage(
            "", "Template läuft. Bitte warten..."
        )
        status_message.layout().addWidget(self.progress_bar)
        iface.messageBar().pushWidget(status_message, Qgis.Info, 10)

        self.progress_bar.setValue(20)

        with DBConnection(dbname=QKan.config.database.qkan) as db_qkan:

            # SQL-Statements für dieses Modul laden
            db_qkan.loadmodule('template')

            db_qkan.sqlyml(
                'template_sql1',
                'Freier Titel zur Wiedererkennung'
            )

        return True

